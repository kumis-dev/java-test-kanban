public enum TasksStatus {
    NEW,
    IN_PROGRESS,
    DONE
}
